	var host_text = location.host.replace(/\./g, "_")
	var url_obj={}
	    url_obj.host     = location.host
	    url_obj.href     = location.href.replace(/^https?:\/\//, "")
		url_obj.pathname = location.pathname
	send_message("hide", url_obj)
	
	var a=document.createElement("a")
	a.target="_blank"
	
	document.addEventListener("DOMContentLoaded", function(){
		var body       = document.body
		var target_dom = null
		var idx_target_data=null
		var target_div_emoji= null
		var dom_arr    = []
		var dom_hidden_obj = {}
		var can_move   = null
	    var posi0_x    = 0
	    var posi0_y    = 0
	    var posi1_x    = 0
	    var posi1_y    = 0
	    var temp_x     = 0
	    var temp_y     = 0
		var top_win    = 20
		var height_head= 35
		var scrollTop_now=0
		var target_dom_obj={} //selector object
		var selector_text=""  //选择器拼接字符
		var hover_display=""
		
		var style_el=document.createElement("style")
		    style_el.id="style_el"
		var operating_win=document.createElement("div")
		    operating_win.can_rightclick="no"
		    operating_win.className="operating_win"
		    operating_win.style.position ="fixed"
		    operating_win.style.display ="none"
		    operating_win.style.top =top_win+"px"
		    operating_win.style.left ="20px"
		    operating_win.style.width ="300px"
		    //operating_win.style.height="300px"
		    operating_win.style.overflow="auto"
		    operating_win.style.backgroundColor="#333"
		    operating_win.style.borderRadius="10px"
		    operating_win.style.boxShadow="0 0 3px rgba(0,0,0,0.6)"
		    operating_win.style.boxSizing="border-box"
		    //operating_win.style.padding="0px"
			operating_win.style.cursor="-webkit-grab"
	        operating_win.style.userSelect="none"
	        operating_win.style.webkitUserDrag="none"
		    operating_win.style.zIndex="999999999"
		var head=document.createElement("div")
		    head.can_rightclick="no"
		    head.className="head"
		    head.style.width="100%"
		    head.style.height=height_head+"px"
			head.style.background="#ddd"
			head.style.borderRadius="8px 8px 0 0"
		    head.style.display="flex"
		    head.style.justifyContent="flex-start"
		    head.style.alignItems="center"
		var close_win=document.createElement("div")
		    close_win.can_rightclick="no"
		    close_win.className="close_win"
			close_win.style.marginLeft="10px"
			close_win.style.width ="15px"
			close_win.style.height="15px"
			close_win.style.borderRadius="100px"
			close_win.style.background="#FF6259"
			close_win.style.cursor="auto"
		var items=document.createElement("div")
		    items.can_rightclick="no"
		    items.className="items"
			items.style.backgroundColor="#fff"
		    items.style.display ="flex"
		    items.style.flexWrap="wrap"
		    items.style.justifyContent="flex-start"
		    items.style.alignItems="flex-start"
		var sub_butt=document.createElement("div")
		    sub_butt.can_rightclick="no"
		    sub_butt.className="sub_butt"
		    sub_butt.style.backgroundColor="#333"
		    sub_butt.style.color="#fff"
		    sub_butt.style.fontSize="16px"
		    sub_butt.style.fontWeight="300"
		    sub_butt.style.padding="8px 0"
		    sub_butt.style.textAlign="center"
			sub_butt.style.borderRadius="0 0 8px 8px"
			
		head.appendChild(close_win)
		operating_win.appendChild(head)
		operating_win.appendChild(items)
		operating_win.appendChild(sub_butt)
		
		head.addEventListener("mousedown", mousedown)
	    document.addEventListener("mousemove", mousemove)
	    document.addEventListener("mouseup", mouseup)
		
		close_win.onclick=function(){
			operating_win.style.display = "none"
			pingbi_cover.style.display  = "none"
		}
		
		sub_butt.onclick=function(){
			if(this.type=="hide"){
				operating_win.style.display = "none"
			    do_hide()
			}
			else{
				change_hidden_data()
			}
		}
		
		var pingbi_cover=document.createElement("div")
			pingbi_cover.can_rightclick="no"
			pingbi_cover.className="pingbi_cover"
			pingbi_cover.style.display="none"
			pingbi_cover.style.position="absolute"
			pingbi_cover.style.backgroundImage="url("+chrome.extension.getURL('pinstriped_suit.png')+")"
			pingbi_cover.style.opacity="0.6"
			pingbi_cover.style.zIndex="99999999"
		
		//拖动搜索
	    document.addEventListener("dragend"  , function(e){
	    	if(window.getSelection().toString()){
	    		var text=window.getSelection().toString().replace(/#/g, "")
	    	    var newURL="https://www.baidu.com/s?wd="+text
	    	    a.href=newURL
	    	    a.click()
	    	}
	    })
		
		//点击右键菜单
		document.addEventListener("contextmenu", function(e){
			var this_target=e.target
			if(this_target.can_rightclick!=="no"){
				target_dom       = null
			    target_div_emoji = null
			    dom_arr          = []
				
			    for(var i=0;i<9;i++){
			    	if(this_target){
						if(["BODY", "HTML"].indexOf(this_target.tagName)==-1){
			    	        dom_arr.push(this_target)
						}
						else{
							break
						}
			    	}
			    	if(this_target.parentNode){
			    	    this_target=this_target.parentNode
			    	}
			    }
			}
		})
		
		function mousedown(e){
	    	posi0_x=e.clientX
	    	posi0_y=e.clientY
	    	can_move=true
	    }
        
	    function mousemove(e){
	        //e.preventDefault()
	    	if(can_move){
	    		temp_x=e.clientX-posi0_x+posi1_x
	    		temp_y=e.clientY-posi0_y+posi1_y
	    		operating_win.style.transition="0ms"
	    		if(temp_y<window.innerHeight/2){
	    		    temp_y=Math.max(temp_y, 0-top_win)
	    		    operating_win.style.transform="translate3d("+temp_x+"px, "+temp_y+"px, 0)"
	    		}
	    		else{
	    		    temp_y=Math.min(temp_y, window.innerHeight-top_win-height_head)
	    		    operating_win.style.transform="translate3d("+temp_x+"px,"+temp_y+"px, 0)"
	    		}
	    	}
	    }
        
	    function mouseup(e){
	        if(can_move){
	    	    can_move=false		
	    	    posi1_x=temp_x
	    	    posi1_y=temp_y
	    	}
	    }
		
		function create_items(idx, type){
			var div_emoji=document.createElement("img")
			div_emoji.className="div_emoji"
			div_emoji.idx=idx
			div_emoji.can_rightclick="no"
			if(type=="hide"){
			    div_emoji.src=chrome.extension.getURL('normal_emoji.png')
				sub_butt.innerText="隐藏"
			}
			else{
				if(typeof dom_hidden_obj[dom_arr[idx].time] !== "undefined"){
					var display=getComputedStyle(dom_hidden_obj[dom_arr[idx].time].dom).display
					if(display=="none"){
						div_emoji.src=chrome.extension.getURL('unhappy_emoji.png')
					}
					else{
						div_emoji.src=chrome.extension.getURL('normal_emoji.png')
					}
				}
				else{
				    if(style_el.innerText){
				        if(/(.+)\{/.exec(style_el.innerText)[1]==dom_arr[idx].selector_short || /(.+)\{/.exec(style_el.innerText)[1]==dom_arr[idx].selector_long){
				        	div_emoji.src=chrome.extension.getURL('normal_emoji.png')
				        }
				        else{
				            div_emoji.src=chrome.extension.getURL('unhappy_emoji.png')
				        }
				    }
				    else{
				    	div_emoji.src=chrome.extension.getURL('unhappy_emoji.png')
				    }
				}
				sub_butt.innerText="在当前网页不隐藏"
			}
			sub_butt.type=type
			div_emoji.style.flex="0 0 auto"
			div_emoji.style.display="block"
			div_emoji.style.margin="15px 20px"
			div_emoji.style.width="60px"
			div_emoji.style.cursor="pointer"
			items.appendChild(div_emoji)
			
			div_emoji.onmouseover=function(){
				if(type=="hide"){
					var idx=this.idx
				    hover_display=(getComputedStyle(dom_arr[idx]).display=="none"?"block":getComputedStyle(dom_arr[idx]).display)
				}
			}
			
			div_emoji.onclick=function(){
				if(type=="hide"){
					target_dom=dom_arr[this.idx]
					target_dom_obj.display=hover_display
					
				    var boundingClientRect=target_dom.getBoundingClientRect()
				    scrollTop_now=window.pageYOffset
				    pingbi_cover.style.top=(boundingClientRect.top+scrollTop_now)+"px"
				    pingbi_cover.style.left=(boundingClientRect.left+window.pageXOffset)+"px"
				    pingbi_cover.style.width=boundingClientRect.width+"px"
				    pingbi_cover.style.height=boundingClientRect.height+"px"
				    pingbi_cover.style.display="block"
					
					this.src=chrome.extension.getURL('unhappy_emoji.png')
				}
				else{
					idx_target_data=this.idx
					var hidden_dom=dom_arr[idx_target_data]
					var dom_here=null
					if(typeof dom_hidden_obj[hidden_dom.time] !== "undefined"){
						dom_here=dom_hidden_obj[hidden_dom.time].dom
					}
					
					if(/unhappy/.test(this.src)){
						if(dom_here){
							style_el.innerText=""
							dom_here.style.display=dom_hidden_obj[hidden_dom.time].display
							dom_here.style.visibility="visible"
							dom_here.style.opacity="1"
						}
						else{
						    var selector=""
						    if(hidden_dom.use_type=="short"){
						    	selector=hidden_dom.selector_short
					        }
					        else{
						    	selector=hidden_dom.selector_long
					        }
						    style_el.innerText=selector+"{height:auto; overflow:auto; visibility:visible; opacity:1}"
						}
						this.src=chrome.extension.getURL('normal_emoji.png')
					}
					else{
						if(dom_here){
							dom_here.style.display="none"
							dom_here.style.visibility="hidden"
							dom_here.style.opacity="0"
						}
						style_el.innerText=""
						this.src=chrome.extension.getURL('unhappy_emoji.png')
					}
					
					if(!document.querySelector("#style_el")){
				    	document.body.appendChild(style_el)
				    }
				}
				
				if(target_div_emoji && target_div_emoji !== this){
					if(type=="hide"){
					    target_div_emoji.src=chrome.extension.getURL('normal_emoji.png')
					}
					else{
						target_div_emoji.src=chrome.extension.getURL('unhappy_emoji.png')
					}
				}
				target_div_emoji=this
			}
		}
		
		function show_operating_win(type){
			if(dom_arr.length>0){
			    if(!document.querySelector(".operating_win")){
			        document.body.appendChild(operating_win)
			    }
			    if(!document.querySelector(".pingbi_cover")){
			        document.body.appendChild(pingbi_cover)
			    }
			    items.innerHTML=""
			    
			    for(var i=0,l=dom_arr.length;i<=l;i++){
			    	if(i==l){
			    		var img=new Image()
			    		img.onload=function(){
			    		    operating_win.style.display = "block"	
			    		}
						if(type=="hide"){
			    		    img.src=chrome.extension.getURL('normal_emoji.png')
						}
						else{
							img.src=chrome.extension.getURL('unhappy_emoji.png')
						}
			    	}
			    	else{
			    	    create_items(i, type)
			    	}
			    }
			}
		}
		
		function do_hide(){
			var div_emojis=items.querySelectorAll(".div_emoji")
			var num_rest_emojis=div_emojis.length
			for(var i=div_emojis.length-1;i>=-1;i--){
				if(i==-1){
					if(num_rest_emojis==0){
						operating_win.style.display = "none"
					}
				}
				else{
				    if(i<=target_div_emoji.idx){
						num_rest_emojis-=1
				    	items.removeChild(div_emojis[i])
				    }
				}
			}
			
			pingbi_cover.style.display = "none"
			
			target_dom.style.display   = "none"
			target_dom.style.visibility= "hidden"
			target_dom.style.opacity   = "0"
			
			target_dom_obj.selector_short=""
			
			if(target_dom.id){
            	selector_text="#"+target_dom.id
				target_dom_obj.selector_short=selector_text
				var parentNode=target_dom.parentNode
				if(parentNode==body){
					after_get_result()
				}
				else{
					next_find(parentNode)
				}
            }
            else{
	            if(target_dom.className){
					var className="."+target_dom.className.replace(/^\s|\s$/, "").replace(/ /g, ".")
					var parentNode=target_dom.parentNode
	        		var doc_all_class=document.querySelectorAll(className)
					if(doc_all_class.length==1){ //元素本身只有一个
						selector_text=className
						target_dom_obj.selector_short=selector_text
						if(parentNode==body){
				        	after_get_result()
				        }
				        else{
				        	next_find(parentNode)
				        }
					}
					else{
	        		    var parent_all_tag=parentNode.querySelectorAll(target_dom.tagName)
						var parent_all_class=parentNode.querySelectorAll(className)
						var parent_all_tag_ok=[]
	        		    var idx=0
	        		    for(var i=0;i<parent_all_tag.length;i++){
	        		    	if(parent_all_tag[i].parentNode==parentNode){
	        		    		parent_all_tag_ok.push(parent_all_tag[i])
	        		    	}
	        		    }
					    if(parent_all_tag_ok.length==1 && parent_all_class.length==1){
					    	selector_text=className
					    }
					    else{
	        		        for(var i=0;i<parent_all_tag_ok.length;i++){
	        		        	if(parent_all_tag_ok[i]==target_dom){
	        		        		idx=i
	        		        		break
	        		        	}
	        		        }
					    	selector_text=className+":nth-of-type("+(idx+1)+")"
					    }
						if(parentNode==body){
							target_dom_obj.selector_short=selector_text
							after_get_result()
	        		    }
	        		    else{
	        		    	next_find(parentNode)
	        		    }
					}
	        	}
	        	else{
	        		var tagName=target_dom.tagName
					var parentNode=target_dom.parentNode
	        		var parent_all_tag=parentNode.querySelectorAll(tagName)
					var parent_all_tag_ok=[]
	        		var idx=0
	        		for(var i=0;i<parent_all_tag.length;i++){
	        			if(parent_all_tag[i].parentNode==parentNode){
	        				parent_all_tag_ok.push(parent_all_tag[i])
	        			}
	        		}
					if(parent_all_tag_ok.length==1){
						selector_text=tagName
					}
					else{
	        		    for(var i=0;i<parent_all_tag_ok.length;i++){
	        		    	if(parent_all_tag_ok[i]==target_dom){
	        		    		idx=i
	        		    		break
	        		    	}
	        		    }
						selector_text=tagName+":nth-of-type("+(idx+1)+")"
					}
					if(parentNode==body){
						target_dom_obj.selector_short=selector_text
						after_get_result()
	        		}
	        		else{
	        			next_find(parentNode)
	        		}
	        	}
	        }
		}
        
        function next_find(node){
	    	if(node.id){
				var parentNode=node.parentNode
	    		selector_text="#"+node.id+" > "+selector_text
				if(!target_dom_obj.selector_short){
					target_dom_obj.selector_short=selector_text
				}
				
	    		if(parentNode==body){
					if(selector_text!=target_dom_obj.selector_short){
	    		        target_dom_obj.selector_long=selector_text
					}
	    		    after_get_result()
	    		}
	    		else{
					next_find(parentNode)
	    		}
	    	}
	    	else{
	    		if(node.className){
					var className="."+node.className.replace(/^\s|\s$/, "").replace(/ /g, ".")
					var parentNode=node.parentNode
	        		var doc_all_class=document.querySelectorAll(className)
					if(doc_all_class.length==1){ //父元素本身只有一个
						selector_text=className+" > "+selector_text
						if(!target_dom_obj.selector_short){
						    target_dom_obj.selector_short=selector_text
						}
						
						if(parentNode==body){
							if(selector_text!=target_dom_obj.selector_short){
							    target_dom_obj.selector_long=selector_text
							}
				        	after_get_result()
				        }
				        else{
				        	next_find(parentNode)
				        }
					}
					else{
	        		    var parent_all_tag=parentNode.querySelectorAll(node.tagName)
						var parent_all_class=parentNode.querySelectorAll(className)
						var parent_all_tag_ok=[]
	        		    var idx=0
	        		    for(var i=0;i<parent_all_tag.length;i++){
	        		    	if(parent_all_tag[i].parentNode==parentNode){
	        		    		parent_all_tag_ok.push(parent_all_tag[i])
	        		    	}
	        		    }
					    if(parent_all_tag_ok.length==1 && parent_all_class.length==1){
					    	selector_text=className+" > "+selector_text
					    }
					    else{
	        		        for(var i=0;i<parent_all_tag_ok.length;i++){
	        		        	if(parent_all_tag_ok[i]==node){
	        		        		idx=i
	        		        		break
	        		        	}
	        		        }
					    	selector_text=className+":nth-of-type("+(idx+1)+") > "+selector_text
					    }
						if(parentNode==body){
							if(!target_dom_obj.selector_short){
								target_dom_obj.selector_short=selector_text
							}
							if(selector_text!=target_dom_obj.selector_short){
							    target_dom_obj.selector_long=selector_text
							}
							after_get_result()
	        		    }
	        		    else{
	        		    	next_find(parentNode)
	        		    }
					}
	    		}
	    		else{
	    		    var tagName=node.tagName
					var parentNode=node.parentNode
	        		var parent_all_tag=parentNode.querySelectorAll(tagName)
					var parent_all_tag_ok=[]
	        		var idx=0
	        		for(var i=0;i<parent_all_tag.length;i++){
	        			if(parent_all_tag[i].parentNode==parentNode){
	        				parent_all_tag_ok.push(parent_all_tag[i])
	        			}
	        		}
					if(parent_all_tag_ok.length==1){
						selector_text=tagName+" > "+selector_text
					}
					else{
	        		    for(var i=0;i<parent_all_tag_ok.length;i++){
	        		    	if(parent_all_tag_ok[i]==node){
	        		    		idx=i
	        		    		break
	        		    	}
	        		    }
						selector_text=tagName+":nth-of-type("+(idx+1)+") > "+selector_text
					}
					if(parentNode==body){
						if(!target_dom_obj.selector_short){
							target_dom_obj.selector_short=selector_text
						}
						if(selector_text!=target_dom_obj.selector_short){
						    target_dom_obj.selector_long=selector_text
						}
						after_get_result()
	        		}
	        		else{
	        			next_find(parentNode)
	        		}
	    		}
	    	}
        }
		
		function after_get_result(){
	    	console.log(target_dom_obj)
			target_dom_obj.time=String(Date.now())
			send_message("save_data", {host:url_obj.host, href:url_obj.href, selector_obj:target_dom_obj})
			
			var obj_dom={}
			    obj_dom.dom     = target_dom
			    obj_dom.display = target_dom_obj.display
			dom_hidden_obj[target_dom_obj.time]=obj_dom
	    }
		
		function change_hidden_data(){
			//判断是完全匹配还是模糊匹配
			if(dom_arr[idx_target_data].use_type=="short"){
				if(typeof dom_arr[idx_target_data].selector_long !== "undefined"){
				    dom_arr[idx_target_data].use_type="long"
				}
				else{
					dom_arr.splice(idx_target_data, 1)
				}
			}
			else{
				dom_arr.splice(idx_target_data, 1)
			}
			
			var data_obj={}
		    data_obj[host_text]=dom_arr
			chrome.storage.local.set(data_obj)
		}
		
		chrome.runtime.onMessage.addListener(function(request, sender, sendResponse){
		    if(request.todo=="show_hide_console"){
				show_operating_win("hide")
			}
			if(request.todo=="show_show_console"){
				idx_target_data=null
				chrome.storage.local.get(host_text, function(c){
					dom_arr=c[host_text]
					show_operating_win("show")
				})
			}
		    if(request.todo=="get_host"){
				sendResponse(host_text)
			}
			if(request.todo=="append_css"){
				style_el.innerText=request.extra
				if(!document.querySelector("#style_el")){
					document.body.appendChild(style_el)
				}
		    }
		})
	})
	
	function send_message(todo, extra, callback){
		chrome.runtime.sendMessage({todo:todo, extra:extra?extra:""}, function(response){
			if(callback){
			    callback(response)
			}
		})
	}