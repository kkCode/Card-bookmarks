    var body_el=document.body
	var screen_width=window.screen.width
	var is_bigger       =localStorage.is_bigger=="yes"?true:false
	var is_use_scrollbar=null
	if(typeof localStorage.is_use_scrollbar == "undefined"){
		is_use_scrollbar=false
	}
	else{
		is_use_scrollbar=localStorage.is_use_scrollbar=="yes"?true:false
	}
	
	body_el.style.width =(is_bigger?screen_width/2:screen_width/4)+"px"
    body_el.style.height=screen_width/4*1.6+"px"
	body_el.style.setProperty("--scrollbar_width", is_use_scrollbar?'8px':'0px')
	
	var wrap=new Vue({
        el:"#wrap",
		data:{
			home_groups_data      : [],
			all_bookmark_data     : {},
			hostname_arr          : [],
			id_level1_arr         : [],
			history_data          : [],
			is_show_group         : true,
			display_to_top        : "none",
			display_children      : "none",
			is_show_children      : false,
			is_bigger             : is_bigger,
			is_use_scrollbar      : is_use_scrollbar,
			children_page_arr     : [],
			viewed_data           : 0,
			key_word              : "",
			search_type           : "bookmarks",
			search_res            : [],
			search_res_b          : [],
			search_res_h          : [],
			display_butt          : "none",
			is_show_butt          : false,
			prev_moveTo_folderIdx : null,
			
			is_right_click        : false,
			deal_array            : [],
			deal_parentId         : null,
			
			move_to_folder_arr    : [],
			move_to_folder_id     : null,
			new_folder_title      : "",
			
			display_move          : "none",
			is_show_move          : false,
			
			display_setting       : "none",
			is_show_setting       : false,
			show_zs_img           : false,
			
			display_edit          : "none",
			is_show_edit          : false,
			show_edit_url         : false,
			bookmark_editing      : {},
			edit_title            : "",
			edit_url              : "",
			
			display_warning       : "none",
			is_show_warning       : false,
			
			warning_con_width     : screen_width/4-20
		},
		watch:{
			is_show_butt:function(){
				if(!this.is_show_butt){
					var that=this
					setTimeout(function(){
						that.display_butt="none"
					}, 300)
				}
			},
			is_show_children:function(){
				if(!this.is_show_children){
					var that=this
					setTimeout(function(){
						that.display_children="none"
					}, 300)
				}
			},
			is_show_move:function(){
				if(!this.is_show_move){
					var that=this
					setTimeout(function(){
						that.display_move="none"
					}, 300)
				}
			},
			is_show_setting:function(){
				if(!this.is_show_setting){
					var that=this
					setTimeout(function(){
						that.display_setting="none"
					}, 300)
				}
			},
			is_show_edit:function(){
				if(!this.is_show_edit){
					var that=this
					setTimeout(function(){
						that.display_edit="none"
					}, 300)
				}
			},
			is_show_warning:function(){
				if(!this.is_show_warning){
					var that=this
					setTimeout(function(){
						that.display_warning="none"
					}, 300)
				}
			},
			
			children_page_arr:function(){
				if(this.children_page_arr.length>0){
				    children_page_con.scrollTop=this.children_page_arr[this.children_page_arr.length-1].scrollTop
				}
			},
			key_word:function(){
				this.search_res_b=[]
				this.search_res_h=[]
				
				var query_arr=this.key_word.toLowerCase().split(/ +/).filter(function(elem){
                    return elem
                })
				var bool_arr_b=[]
				var bool_arr_h=[]
				var l_b=this.all_bookmark_data.item_info.length
				var l_h=this.history_data.length
				
				if(query_arr.length>0){
					var query_arr_length=query_arr.length
				    for(var i=0;i<l_b;i++){
						this.is_show_group=false
						var item_info_b=this.all_bookmark_data.item_info[i]
						var list_now_b=item_info_b.title
						var hostname=item_info_b.hostname
						//多重判断
				    	for(var k_b=0;k_b<=query_arr_length;k_b++){
				    	    if(k_b==query_arr_length){ //最终结果
				    		    if(bool_arr_b.indexOf(false) == -1){
									item_info_b.idx=i
									item_info_b.is_select=false
									this.search_res_b.push(item_info_b)
				    			}
				    		}
				    		else{
				                if(list_now_b.toLowerCase().indexOf(query_arr[k_b]) !== -1 || hostname.toLowerCase().indexOf(query_arr[k_b]) !== -1){
				    				bool_arr_b[k_b]=true
				                }
				                else{
				    				bool_arr_b[k_b]=false
				                }
				    		}
				    	}
				    }
					
					for(var h=0;h<l_h;h++){
						this.is_show_group=false
						var item_info_h=this.history_data[h]
						var list_now_h=item_info_h.title
						var url_h     =item_info_h.url
						//多重判断
				    	for(var k_h=0;k_h<=query_arr_length;k_h++){
				    	    if(k_h==query_arr_length){ //最终结果
				    		    if(bool_arr_h.indexOf(false) == -1){
									this.search_res_h.push(item_info_h)
				    			}
				    		}
				    		else{
				                if(list_now_h.toLowerCase().indexOf(query_arr[k_h]) !== -1 || url_h.toLowerCase().indexOf(query_arr[k_h]) !== -1){
				    				bool_arr_h[k_h]=true
				                }
				                else{
				    				bool_arr_h[k_h]=false
				                }
				    		}
				    	}
				    }
					
					if(this.search_type=="bookmarks"){
				    	if(this.search_res_b.length>0){
				    	    this.search_res=this.search_res_b
				    	}
				    	else{
				    		this.search_type="history"
				    		this.search_res=this.search_res_h
				    	}
				    }
				    else{
				    	if(this.search_res_h.length>0){
				    	    this.search_res=this.search_res_h
				    	}
				    	else{
				    		this.search_type="bookmarks"
				    		this.search_res=this.search_res_b
				    	}
				    }
				}
				else{
					this.search_res=[]
					this.is_show_group=true
					this.cancel_right_click()
				}
			}
		},
		computed:{
			move_to_folder_titles:function(){
				var titles_arr=[]
				if(this.move_to_folder_arr.length>0){
				    this.move_to_folder_arr.forEach(function(item, idx, arr){
				    	titles_arr.push(item.title)
				    })
				}
				return titles_arr
			}
		},
		methods:{
			search_focus:function(){
				if(this.is_show_group){
					this.cancel_right_click()
				}
			},
			presskey:function(e){
				if(e.keyCode==40){ //down
					
				}
				if(e.keyCode==38){ //up
					
				}
				if(e.keyCode==13){ //enter
					
				}
			},
			change_search_type:function(type){
				this.search_type=type
				if(type=="bookmarks"){
					this.search_res=this.search_res_b
				}
				else{
					this.search_res=this.search_res_h
					this.cancel_right_click()
				}
			},
			show_setting_page:function(){
				this.display_setting="block"
				this.is_show_setting=true
			},
			hide_setting_page:function(){
				this.is_show_setting=false
			},
			use_scrollbar:function(){
				this.is_use_scrollbar = !this.is_use_scrollbar
				localStorage.is_use_scrollbar=this.is_use_scrollbar?'yes':'no'
				body_el.style.setProperty("--scrollbar_width", this.is_use_scrollbar?'8px':'0px')
			},
			daochu:function(){
				do_daochu()
			},
			daoru:function(){
				do_daoru()
			},
			show_child_page:function(title, children){
				var obj={}
				    obj.children_title=title
					obj.children      =children
				if(this.children_page_arr.length>0){
				    this.children_page_arr[this.children_page_arr.length-1].scrollTop=children_page_con.scrollTop
				}
				this.children_page_arr.push(obj)
				this.display_children="block"
				this.is_show_children=true
			},
			main_to_top:function(){
				main.scrollTop=0
			},
			scroll_to_top:function(){
				children_page_con.scrollTop=0
			},
			scroll_to_bottom:function(){
				children_page_con.scrollTop=children_page_con.scrollHeight
			},
			bigger:function(){
				this.is_bigger=!this.is_bigger
				if(this.is_bigger){
					localStorage.is_bigger="yes"
				    body_el.style.width=screen_width/2+"px"
				}
				else{
					localStorage.is_bigger="no"
				    body_el.style.width=screen_width/4+"px"
				}
			},
			get_icon:function(url){
				return "chrome://favicon/"+url
			},
			open_webpage:function(url){
				chrome.tabs.create({url: url})
			},
			hide_children_page:function(){
				if(this.is_show_children){
				    this.is_show_children=false
				    var that=this
				    setTimeout(function(){
				        that.children_page_arr.splice(0, that.children_page_arr.length)
				    }, 300)
				}
			},
			back:function(){
				if(this.children_page_arr.length==1){
					this.is_show_children=false
					var that=this
					setTimeout(function(){
						that.children_page_arr.splice(0, 1)
					}, 300)
				}
				else{
					this.children_page_arr.splice(this.children_page_arr.length-1, 1)
				}
				this.cancel_right_click()
			},
            click:function(array, idx){
				var item=array[idx]
				if(!this.is_right_click){
					if(item.children){
					    this.show_child_page(item.title, item.children)
					}
					else{
						this.open_webpage(item.url)
					}
				}
				else{
					if(!item.is_select){
					    array[idx].is_select=true
					}
					else{
						array[idx].is_select=false
					}
				}
			},
            right_click:function(parentId, array, idx){
				if(!this.is_right_click){
					this.is_right_click=true
					this.deal_array    =array
					this.deal_parentId =parentId
					this.display_butt="block"
					this.is_show_butt=true
					
					array[idx].is_select=true
				}
				else{
					this.cancel_right_click()
				}
			},
			cancel_right_click:function(){
				this.is_right_click=false
				this.is_show_butt  =false
				this.deal_array.forEach(function(item){
					item.is_select=false
				})
			},
			get_selected_data:function(callback){
				var arr_id =[]
				var arr_idx=[]
				var arr_all=[]
				for(var i=0, l=this.deal_array.length;i<l;i++){
					if(this.deal_array[i].is_select){
					    arr_id.push(this.deal_array[i].id)
					    arr_idx.push(i)
					    arr_all.push(this.deal_array[i])
					}
				}
				callback({"arr_id":arr_id, "arr_idx":arr_idx, "arr_all":arr_all})
			},
			edit:function(){
				var that=this
				this.get_selected_data(function(obj){
					if(obj.arr_id.length>0){
						var the_bookmark=obj.arr_all[0]
						console.log(the_bookmark)
						
						if(typeof the_bookmark.children == "undefined"){
							that.show_edit_url= true
							that.edit_url     = the_bookmark.url
						}
						else{
							that.show_edit_url= false
						}
						
						that.bookmark_editing = the_bookmark
						that.edit_title   = the_bookmark.title
						that.display_edit = "block"
						that.is_show_edit = true
						that.cancel_right_click()
					}
				})
			},
			finish_edit:function(){
				var that  = this
				var change_obj={}
				if(this.edit_title){
				    if(this.show_edit_url){
				    	change_obj.title=this.edit_title
				    	change_obj.url  =this.edit_url
				    	this.bookmark_editing.title=this.edit_title
				    	this.bookmark_editing.url  =this.edit_url
				    }
				    else{
				    	change_obj.title=this.edit_title
				    	this.bookmark_editing.title=this.edit_title
				    }
				    
				    chrome.bookmarks.update(this.bookmark_editing.id, change_obj, function(){
				    	console.log(that.bookmark_editing)
				    	that.hide_edit()
				    })
				}
			},
			hide_edit:function(){
				this.is_show_edit = false
			},
			fixed_to_top:function(){
				var that=this
				this.get_selected_data(function(obj){
					if(obj.arr_id.length>0){
						var home_parentId=that.home_groups_data[0][0].parentId
						for(var l=obj.arr_id.length, i=l-1;i>=0;i--){
							chrome.bookmarks.move(obj.arr_id[i], {parentId:home_parentId, index:0})
						}
						get_data()
					}
				})
				
				this.cancel_right_click()
				this.hide_children_page()
			},
			show_delete_warning:function(){
				this.display_warning = "block"
				this.is_show_warning = true
				this.is_show_butt    = false
			},
			hide_warning:function(){
				this.cancel_right_click()
				this.is_show_warning=false
			},
			do_delete:function(){
				var that=this
				this.get_selected_data(function(obj){
					if(obj.arr_id.length>0){
						//倒循环
						for(var l=obj.arr_id.length, i=l-1;i>=0;i--){
							var id =obj.arr_id[i]
							var idx_dealArray=obj.arr_idx[i]
							var index_of=that.all_bookmark_data.folder_id.indexOf(id)
							if(index_of==-1){
								chrome.bookmarks.remove(id)
								that.deal_array.splice(idx_dealArray, 1)
							}
							else{
							    if(that.all_bookmark_data.folder[index_of].children.length==0){
									chrome.bookmarks.remove(id)
									that.deal_array.splice(idx_dealArray, 1)
								}
						    }
						}
						
						get_data()
					}
				})
				
				this.cancel_right_click()
				this.hide_warning()
				this.hide_children_page()
			},
			show_move_page:function(){
				var that=this
				var all_folder_arr=this.all_bookmark_data.folder
				var move_to_folder_arr=[]
				this.get_selected_data(function(obj){
					if(obj.arr_id.length>0){
						all_folder_arr.forEach(function(item, idx, arr){
							if(obj.arr_id.indexOf(item.id) == -1){
				        		move_to_folder_arr.push({id:item.id, is_select:false, title:item.title})
				        	}
				        })
						move_to_folder_arr.unshift({id:'', is_select:false})
						that.move_to_folder_arr = move_to_folder_arr
				        that.new_folder_title   = ""
				        that.display_move       = "block"
				        that.is_show_move       = true
				        that.is_show_butt       = false
					}
				})
			},
			hide_move_page:function(){
				this.cancel_right_click()
				this.is_show_move=false
			},
			select_move_to_folder:function(folder_id, idx){
				this.move_to_folder_arr[idx].is_select=true
				if(this.prev_moveTo_folderIdx !== null && this.prev_moveTo_folderIdx !== idx){
					this.move_to_folder_arr[this.prev_moveTo_folderIdx].is_select=false
				}
				
				this.prev_moveTo_folderIdx = idx
				this.move_to_folder_id     = folder_id
			},
			move_finish:function(){
				this.cancel_right_click()
				this.hide_move_page()
				this.hide_children_page()
			},
			do_move:function(){
				var that=this
				if(that.move_to_folder_id){
					this.get_selected_data(function(obj){
				    	if(obj.arr_id.length>0){
							obj.arr_id.forEach(function(id){
								chrome.bookmarks.move(id, {parentId:that.move_to_folder_id, index:0})
							})
				    		get_data()
				    	}
						that.move_finish()
				    })
				}
				else{
					if(this.new_folder_title !=="" && this.new_folder_title.replace(/\s/g, "").length>0){
						var new_folder_title=this.new_folder_title.replace(/^\s+/, "").replace(/\s+$/, "")
						var that=this
						var obj ={}
						if(this.move_to_folder_titles.indexOf(new_folder_title) == -1){
	                        obj.parentId = this.home_groups_data[0][0].parentId
	                        obj.index    = 0
	                        obj.title    = new_folder_title
						    chrome.bookmarks.create(obj, function(c){
								that.get_selected_data(function(data_obj){
				                	if(data_obj.arr_id.length>0){
										data_obj.arr_id.forEach(function(id){
							            	chrome.bookmarks.move(id, {parentId:c.id, index:0})
							            })
				                		get_data()
				                	}
					            	that.move_finish()
				                })
						    })
						}
					}
				}
			},
			language:function(name){
	        	return chrome.i18n.getMessage(name)
	        }
		}
    })
	
	var main             =wrap.$el.querySelector("#main")
	var children_page_con=wrap.$el.querySelector(".children_page_con")
	
	chrome.storage.local.get("viewed_data", function(c){
		if(typeof c.viewed_data=="undefined"){
			wrap.viewed_data=0
		}
		else{
			var viewed_data=c.viewed_data
			if(viewed_data.riqi == riqi()){
				wrap.viewed_data=c.viewed_data.num_tabs
			}
			else{
				wrap.viewed_data=0
			}
		}
	})
	
	get_data()
	get_data_history()
	
	function get_data(callback){
		var t=Date.now()
	    chrome.bookmarks.getTree(function(c){
			console.log(c)
	    	var arr=c[0].children
			
	    	var arr1=arr.filter(function(item, idx){
	    		return (typeof item.children !== "undefined")
	    	})
	    	
	    	var arr2         = []
			var hostname_arr = []
			var a_tag        = document.createElement("a")
			
			var all_bookmark_obj = {}
			    all_bookmark_obj.item_info = []
			    all_bookmark_obj.folder    = []
			    all_bookmark_obj.folder_id = []
			
	    	for(var i=0;i<arr1.length;i++){
				wrap.id_level1_arr.push(arr1[i].id)
				
	    		var children = arr1[i].children
				var folder   = []
				var item     = []
				for(var k=0;k<children.length;k++){
					children[k].is_select=false
					if(typeof children[k].children == "undefined"){
						item.push(children[k])
						
						a_tag.href=children[k].url
						var hostname=a_tag.hostname.replace(/^www\./, "").replace(/\.[^\.]+$/, "")
						children[k].hostname = hostname
						if(hostname_arr.indexOf(hostname) == -1){
							hostname_arr.push(hostname)
						}
					    all_bookmark_obj.item_info.push(children[k])
					}
					else{
						folder.push(children[k])
						all_bookmark_obj.folder.push(children[k])
						all_bookmark_obj.folder_id.push(children[k].id)
						continue_deal(children[k].children)
					}
				}
	    		arr2.push(item.concat(folder)) //让书签在前，文件夹在后
	    	}
	    	
	    	wrap.home_groups_data=arr2
			//console.log(Date.now()-t)
			
			wrap.all_bookmark_data = all_bookmark_obj
		    wrap.hostname_arr      = hostname_arr
			
			if(callback){
			    callback("get_data_finish")
			}
			
			function continue_deal(array){
		    	for(var j=0;j<array.length;j++){
					array[j].is_select=false
		    		if(typeof array[j].children == "undefined"){
						a_tag.href=array[j].url
						var hostname=a_tag.hostname.replace(/^www\./, "").replace(/\.[^\.]+$/, "")
						array[j].hostname = hostname
					    all_bookmark_obj.item_info.push(array[j])
						if(hostname_arr.indexOf(hostname) == -1){
							hostname_arr.push(hostname)
						}
		    		}
					else{
						all_bookmark_obj.folder.push(array[j])
						all_bookmark_obj.folder_id.push(array[j].id)
						continue_deal(array[j].children)
					}
		    	}
		    }
	    })
	}
	
	function get_data_history(){
		chrome.history.search({text:"", maxResults:1000}, function(c){
			wrap.history_data=c
		})
	}
	
	function riqi(){
		var date_obj=new Date()
		var month=date_obj.getMonth()+1
		var date=/(\d+) (\d+) (\d+:\d+:\d+)/g.exec(date_obj)
		return date[2]+"-"+(month<10?'0'+month:month)+"-"+date[1]
	}
	
	function save_data_to_file(text, fileName){
        var b = new Blob([text], {type: 'text/plain; charset=utf-8'})
		var url=URL.createObjectURL(b)
		chrome.downloads.download({
			"url":url,
			"filename":fileName,
			"saveAs":!!0
		})
		
        /*var a = main.$el.querySelector("#download")
        a.href     = url
        a.download = fileName
        a.click()
        URL.revokeObjectURL(b)*/
    }
	
	function do_daochu(){
		get_data(function(c){
			if(c=="get_data_finish"){
		    	if(wrap.all_bookmark_data.folder.length>0){
		    	    var folder=wrap.all_bookmark_data.folder
		            var item  =wrap.all_bookmark_data.item_info
		            var obj={}
		            obj.is_bookmarks3721 = true
		            obj.all_items        = folder.concat(item)
		            obj.id_level1_arr    = wrap.id_level1_arr
		            
		            var _text=JSON.stringify(obj)
		            save_data_to_file(_text, 'card_bookmarks.json')
		        }
			}
		})
	}
	
	function do_daoru(){
		var input_file=document.querySelector("#file")
		input_file.onchange=function(e){
			var file=e.target.files[0]
			var fr=new FileReader()
			fr.onload=function(){
	            var str=this.result
				if(str.indexOf("is_bookmarks3721") !== -1){
	                var json=JSON.parse(str)
				    var data_check      = json.is_bookmarks3721
	                var id_level1_arr   = json.id_level1_arr
	                var all_items       = json.all_items
	                var level1_item_obj = {}
	                var level1_item = []
	                var other_item  = []
	                if(data_check && all_items.length>0){
	                    for(var i=0;i<all_items.length;i++){
	                    	if(id_level1_arr.indexOf(all_items[i].parentId) !== -1){
	                    		if(typeof level1_item_obj["p"+all_items[i].parentId] == "undefined"){
	                    			level1_item_obj["p"+all_items[i].parentId]=[]
	                    		}
	                    		level1_item_obj["p"+all_items[i].parentId].push(all_items[i])
	                    	}
	                    	else{
	                    		other_item.push(all_items[i])
	                    	}
	                    }
	                    
	                    for(var i in level1_item_obj){
	                    	level1_item_obj[i].sort(function(a, b){
	                        	return a.index-b.index
	                        })
	                    	level1_item.push(level1_item_obj[i]) //[[],[]]
	                    }
	                    
	                    for(var i=0;i<level1_item.length;i++){
	                        for(var k=0;k<level1_item[i].length;k++){
	                    		level1_item[i][k].parentId=String((i+1))
	                    	}
	                    }
	                    //console.log(level1_item)
	                    var all_same_parentId=[]
	                    
	                    create(level1_item, 0, 0)
	                }
	                
	                function create(array, array_idx, array_in_idx){
	                	if(array[array_idx][array_in_idx]){
	                	    var id_old=array[array_idx][array_in_idx].id
	                	    var obj={}
	                	    obj.parentId=array[array_idx][array_in_idx].parentId
	                	    obj.index   =array[array_idx][array_in_idx].index
	                	    obj.title   =array[array_idx][array_in_idx].title
	                	    var is_folder=null
	                	    if(typeof array[array_idx][array_in_idx].url !== "undefined"){
	                	    	obj.url=array[array_idx][array_in_idx].url
	                	    	is_folder=false
	                	    }
	                	    else{
	                	    	is_folder=true
	                	    }
	                	    chrome.bookmarks.create(obj, function(c){
	                	    	if(is_folder){
	                	    	    var the_same_parentId=[]
	                	    	    for(var j=0;j<other_item.length;j++){
	                	    			if(typeof other_item[j].can_modify == "undefined"){
	                	    				other_item[j].can_modify=true
	                	    			}
	                	            	if(other_item[j].parentId==id_old && other_item[j].can_modify){
	                	            		other_item[j].parentId=c.id
	                	            		other_item[j].can_modify=false
	                	            		the_same_parentId.push(other_item[j])
	                	            	}
	                	            }
	                	    	    if(the_same_parentId.length>0){
	                	    			the_same_parentId.sort(function(a, b){
	                	    	        	return a.index-b.index
	                	    	        })
	                	    			all_same_parentId.push(the_same_parentId)
	                	    	    }
	                	    	}
				    			
	                	    	if(array_in_idx<array[array_idx].length-1){
	                	    		create(array, array_idx, array_in_idx+1)
	                	    	}
	                	    	else{
	                                if(array_idx<array.length-1){
	                                	create(array, array_idx+1, 0)
	                                }
	                                else{
	                                	if(all_same_parentId.length>0){
	                	    				if(array !== all_same_parentId){
	                                	        create(all_same_parentId, 0, 0)
	                	    				}
	                	    				else{
	                	    					get_data()
	                	    				}
	                                	}
	                	    			else{
	                	    				get_data()
	                	    			}
	                                }
	                	    	}
	                	    })
	                    }
	                }
	            }
			}
			fr.readAsText(file)
		}
		input_file.click()
	}
	
	document.addEventListener("contextmenu", function(e){
        if(["INPUT", "TEXTAREA"].indexOf(e.target.tagName) == -1){
			e.preventDefault()
		}
    })
	
	main.onscroll=function(){
		if(main.scrollTop>window.innerHeight/2){
			wrap.display_to_top="block"
		}
		else{
			wrap.display_to_top="none"
		}
	}
	
	function sent_to_contentScript(todo, extra, callback){
    	chrome.tabs.query({active: true,currentWindow: true},function (tabs){
            chrome.tabs.sendMessage(tabs[0].id,{todo: todo, extra: extra},function(response){
				if(callback){
					if(response){
				        callback(response)
					}
					else{
						callback(null)
					}
				}
            })
        })
    }