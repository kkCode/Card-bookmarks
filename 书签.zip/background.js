    chrome.tabs.onCreated.addListener(function(tab_info){
		chrome.storage.local.get("viewed_data", function(c){
			if(typeof c.viewed_data=="undefined"){
				var json ={}
				var json1={}
				    json1.riqi=riqi()
				    json1.num_tabs=1
				json.viewed_data=json1
				chrome.storage.local.set(json)
			}
			else{
				var viewed_data=c.viewed_data
				if(viewed_data.riqi == riqi()){
					c.viewed_data.num_tabs=c.viewed_data.num_tabs+1
					chrome.storage.local.set(c)
				}
				else{
					var json ={}
				    var json1={}
				        json1.riqi=riqi()
				        json1.num_tabs=1
				    json.viewed_data=json1
				    chrome.storage.local.set(json)
				}
			}
	    })
	})
	
	chrome.runtime.onMessage.addListener(function(request, sender, sendResponse){
		
	})
	
	function riqi(){
		var date_obj=new Date()
		var month=date_obj.getMonth()+1
		var date=/(\d+) (\d+) (\d+:\d+:\d+)/g.exec(date_obj)
		return date[2]+"-"+(month<10?'0'+month:month)+"-"+date[1]
	}
	
	function sendMessage(todo, extra, callback){
		chrome.tabs.query({active:true, currentWindow: true},function (tabs){
		    chrome.tabs.sendMessage(tabs[0].id,{todo: todo, extra:extra},function(response){
                if(callback){
				    callback(response)
				}
	        })
	    })
	}